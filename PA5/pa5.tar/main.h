#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct item
{
	char* name;
	int value;
	int weight;
	int itemAmount;
} item;

typedef item* InventoryEntry;

InventoryEntry* InitInventory(int cap, char* fileName);

void FreeInventory(InventoryEntry* inventory);

int MaximizeInventory(int cap);