#include "main.h"

void main(int argc, char** argv)
{
	printf("%s\n", argv[1]);

	InventoryEntry* inventory = InitInventory(10, argv[1]);
	printf("%s",inventory[2]->name);
	printf("");
	FreeInventory(inventory);
}